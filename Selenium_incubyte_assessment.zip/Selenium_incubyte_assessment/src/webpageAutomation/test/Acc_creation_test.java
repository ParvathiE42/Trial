package webpageAutomation.test;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import webpageAutomation.base.BaseTest;
import webpageAutomation.page.Acc_creation_page;

public class Acc_creation_test extends BaseTest {

	public Acc_creation_page Accpage;
	
	@BeforeMethod
	public void beforeMethod() {
		Accpage = new Acc_creation_page(driver);
	}
	
	@Test
	public void LoginWithValidUser() throws Exception {
		Accpage.ClickToCreateAnAccount_Link();
		Thread.sleep(2000);
		Accpage.Login("Parvathi", "E", "new@gmail.com", "Demoacc@12", "Demoacc@12");
		Thread.sleep(2000);
	}
	

}
