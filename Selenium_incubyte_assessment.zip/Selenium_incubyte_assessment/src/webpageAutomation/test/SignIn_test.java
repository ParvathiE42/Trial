package webpageAutomation.test;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import webpageAutomation.base.BaseTest;
import webpageAutomation.page.SignIn_page;

public class SignIn_test extends BaseTest {
        public SignIn_page SignInpage;
	
	@BeforeMethod
	public void beforeMethod() {
		SignInpage = new SignIn_page(driver);
	}
	
	@Test
	public void SignInWithValidUser() throws Exception {
		SignInpage.ClickSignIn();
		Thread.sleep(2000);
		SignInpage.SignIn("new@gmail.com", "Demoacc@12");
		System.out.println("Valid User");
		Thread.sleep(2000);
	}
	
	@Test
	public void SignInWithInValidUser() throws Exception {
		SignInpage.ClickSignIn();
		Thread.sleep(2000);
		SignInpage.SignIn("demo01@gmail.com", "fdfgig");
		System.out.println("Invalid User");
		Thread.sleep(2000);
	}
	
	

}
