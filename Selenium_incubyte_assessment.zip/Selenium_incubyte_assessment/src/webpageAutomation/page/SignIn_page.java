package webpageAutomation.page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SignIn_page {
public WebDriver driver;
	
	public SignIn_page(WebDriver driver){
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="/html/body/div[2]/header/div[1]/div/ul/li[2]/a")
	private WebElement SignIn_Link;
	
	@FindBy(xpath="//*[@id=\"email\"]")
	private WebElement Email_signin;
	
	@FindBy(xpath="//*[@id=\"pass\"]")
	private WebElement Password_sigin;
	
	@FindBy(xpath ="//*[@id=\"send2\"]")
	private WebElement SignIn_btn;
	
	public void ClickSignIn() {
		SignIn_Link.click();
	}
	
	public void SignIn(String email, String pass) {
		Email_signin.sendKeys(email);
		Password_sigin.sendKeys(pass);
		SignIn_btn.click();
	}
}
